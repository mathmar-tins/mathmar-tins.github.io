from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def pagina_inicial(request):
    # O Django irá procurar por 'index.html' na pasta 'templates/nome_do_app/'
    contexto = {'nome': 'Usuário Django'}
    return render(request, 'website/home.html', contexto)

def home(request):
    # Dicionário de contexto: envia dados para o template
    contexto = {'titulo': 'Matheus Martins Portfolio'}
    
    # Renderiza o template 'website/home.html'
    return render(request, 'home.html', contexto) 
    
# def sobre(request):
#    return render(request, 'website/sobre.html')