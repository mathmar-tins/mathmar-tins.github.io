# core/urls.py

from django.urls import path
from . import views # Agora essa importação funciona, pois views.py está no app 'core'

urlpatterns = [
    path('', views.pagina_inicial, name='home'),
]